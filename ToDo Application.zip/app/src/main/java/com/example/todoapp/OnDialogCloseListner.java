package com.example.todoapp;

import android.content.DialogInterface;

public interface OnDialogCloseListner {
    void onDialogClose(DialogInterface dialogInterface);
}
